package MazeConcreteObjects;

/**+
 *
 * it is DOOR class. Consist of direction for each door.
 * List doors are stored in room class.
 *
 */
public class Door {
    String direction;

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }
}
