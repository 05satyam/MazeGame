package MazeMapeSiteBaseInterface;

/**+
 *
 * top most abstrct class for the maze obejcts
 */
public interface  MapSiteBaseInterfaceClass {

}
